const { Builder, By, until } = require("selenium-webdriver");

(async function testJiraLogin() {
  let driver = await new Builder().forBrowser("chrome").build();

  try {
    console.log("Navigating to Jira login page...");
    await driver.get("https://id.atlassian.com/login");

    console.log("Waiting for email input...");
    await driver.wait(until.elementLocated(By.id("username")), 10000);
    await driver.findElement(By.id("username")).sendKeys("fakeuser@example.com");
    await driver.findElement(By.id("login-submit")).click();

    await driver.wait(until.elementLocated(By.id("password")), 10000);
    await driver.findElement(By.id("password")).sendKeys("fakePassword123");
    await driver.findElement(By.id("login-submit")).click();

    console.log("Waiting to see if login failed...");
    await driver.wait(until.elementLocated(By.css(".css-1ynzxqw")), 10000);

    let errorMessage = await driver.findElement(By.css(".css-1ynzxqw")).getText();
    if (errorMessage) {
      console.log("Login failed as expected. Error message:", errorMessage);
    } else {
      console.log("Test failed: No error message found.");
    }

  } catch (error) {
    console.error("Error occurred during test:", error);
  } finally {
    await driver.quit();
  }
})();
