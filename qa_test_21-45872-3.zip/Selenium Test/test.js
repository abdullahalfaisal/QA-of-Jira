const {Builder, By, until, Key} = require("selenium-webdriver");

(async function login() {
  
    let driver = await new Builder().forBrowser("chrome").build();

    try{

     
        await driver.get("https://id.atlassian.com/login");
    
       
        await driver.manage().window().maximize();  
  
        await driver.wait(until.elementLocated(By.id("username")), 10000);
       
       
        await driver.findElement(By.id("username")).sendKeys("davagi8772@asimarif.com", Key.RETURN); //davagi8772@asimarif.com , testUser10203040
        
         await driver.wait(until.elementLocated(By.id("password")), 10000);
        const passwordField = await driver.findElement(By.id("password"));
        
        await driver.wait(until.elementIsVisible(passwordField), 10000);
        await driver.wait(until.elementIsEnabled(passwordField), 10000);

        await passwordField.sendKeys("testUser10203040");

        const loginButton = await driver.findElement(By.id("login-submit"));
        await driver.wait(until.elementIsVisible(loginButton), 10000);
        await driver.wait(until.elementIsEnabled(loginButton), 10000);
        await loginButton.click();
        
    }catch (error) {
    console.error("Error occurred during test:", error);
  } 

    })();