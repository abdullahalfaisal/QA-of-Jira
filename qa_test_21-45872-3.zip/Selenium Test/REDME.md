_______This project uses **Selenium WebDriver** with **JavaScript** to test the Jira login functionality_______

1. Installation Instructions
----------------------------

-Make sure Node.js is installed: https://nodejs.org/

-Put the three files you have (test.js, package.json, and README.md) in one folder on your pc/laptop.

-Open a terminal/command prompt in that folder.

-Run this command to install Selenium WebDriver: npm install

-Install Google Chrome browser.

-Download ChromeDriver from:https://sites.google.com/chromium.org/driver/

-Make sure the ChromeDriver version matches your installed Chrome browser version.

-Put the chromedriver executable in a folder included in your system PATH


2. How to Run the Test
----------------------

-To run the test open command prompt on the folder containing test.js, package.json, and README.md  and enter: npm test

3. What the Test Does
---------------------

Step 1: Opens Jira login page in Chrome browser
Step 2: Enters invalid email and submits
Step 3: Enters invalid password and submits
Step 4: Waits for error message on failed login
Step 5: Logs error message text to console
Step 6: Closes browser after test

4. Important Notes
------------------

-The test intentionally uses invalid credentials to verify Jira’s login failure behavior.

-ChromeDriver version must match installed Chrome browser version.

-The script relies on element IDs and CSS classes which may change if Jira updates its UI.

-This test does not perform a successful login due to use of fake credentials.